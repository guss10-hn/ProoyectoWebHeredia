<?php

    //Decirle al php que vamos a utilizar objetos JSON
    header('Content-Type: application/json');
   //Es el archivo del controlador que utilizara para 
   //acceder al modelo a traves de un endpoint y traer los datos en JSON

   require_once("../config/conexion.php");
   require_once("../models/Categoria.php");

   //crear un objeto para utilizar la categoria del models
   $categoria=new Categoria();


   //Decodifique los parametros que enviamos y lo acepte en tipo JSON
   $body=json_decode(file_get_contents("php://input"),true);
   //Crear los servicios a utilizar en los endpoint

   switch($_GET["op"])
   {
      //case para traer todos los registros de la tabla categorias
         case "selectall":$datos=$categoria->getCategoria();
                        echo json_encode($datos);
                        break;
      //case para traer un registro de la tabla categorias
         case "selectid":$datos=$categoria->getCategoria_id($body["cat_id"]);
                        echo json_encode($datos);
                        break;
      //case para insertar un registro en la tabla categorias
         case "insert":$datos=$categoria->postCategoria($body["cat_nom"],$body["cat_obs"]);
                        echo json_encode("Registro Insertado con Exito");
                        break;
      //case para actualizar un registro en la tabla categorias
         case "update":$datos=$categoria->putCategoria($body["cat_nom"],$body["cat_obs"],$body["cat_id"]);
                        echo json_encode("Registro Actualizado con Exito");
                        break;
      //case para traer un registro de la tabla categorias
      case "delete":$datos=$categoria->deleteCategoria($body["cat_id"]);
                        echo json_encode("Registro Borrado con Éxito");
                        break;
      
   }

?>
