<?php

    header('Content-Type: application/json');

    require_once("../config/conexion.php");
    require_once("../models/Productos.php");

    $productos= new Productos();

    $body=json_decode(file_get_contents("php://input"), true);

    switch($_GET["op"])
    {
        case "selectall":$datos=$productos->getProductos();
                        echo json_encode($datos);
                        break;
        case "selectid":$datos=$productos->getProductos_id($body["id"]);
                        echo json_encode($datos);
                        break;
        case "insert":$datos=$productos->postProductos($body["nombre"],$body["pu"],$body["cantidad"],$body["cat_id"]);
                        echo json_encode("Registro Insertado con Éxito");
                        break;
        case "update":$datos=$productos->putProductos($body["nombre"],$body["pu"],$body["cantidad"],$body["cat_id"],$body["id"]);
                        echo json_encode("Registro Actualizado con Éxito");
                        break;
        case "delete":$datos=$productos->deleteProductos($body["id"]);
                        echo json_encode("Registro Eliminado con Éxito");
                        break;
                        
    }

?>