
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <link rel="stylesheet" href="consumer/estilos.css">
</head>
<body> <header id="inicio">
        <div class="contenedor">
            <div class="menu">
            <p></p>
                <ul class="lista">
                    <li><a class="btn-menu" href="consumer/clienteCategoria.php">Categorías</a></li>
                    <li><a class="btn-menu" href="consumer/clienteProductos.php">Productos</a></li>
                    <li><a class="btn-menu"  href="../login.php" >Cerrar Sesion</a></li>
                </ul>
                </div>
        </div>
    </header>
</html>