<?php

   //Clase que se utilizara para crear el modelo que 
   //interactuara con la BD 

   class Categoria extends Conectar
   {

      //funcion para traer todas LOS REGISTROS DE LA TABLA categoria
      public function getCategoria()
      {
        //llamar la cadena de conexion de la BD
        $conectar=parent::conexion();

        //String a ejecutar
        $sql="select * from categoria where est=1";

        //Se prepara la conexion 
        $sql=$conectar->prepare($sql);

        //Ejecutar la conexion
        $sql->execute();

        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);

      }

      //función para traer un registro en especifico
      public function getCategoria_id($cat_id)
      {
        //llamar la cadena de conexion de la BD
        $conectar=parent::conexion();

        //String a ejecutar
        $sql="select * from categoria where est=1 and cat_id=?";

        //Se prepara la conexion 
        $sql=$conectar->prepare($sql);

        //Indicar en el String del SQL el parametro que utilizará
        $sql->bindValue(1,$cat_id);
        //Ejecutar la conexion
        $sql->execute();

        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);

      }

      //Función para agregar un registro en la tabla categoria
      public function postCategoria($cat_nom,$cat_obs)
      {
        //llamar la cadena de conexion de la BD
        $conectar=parent::conexion();

        //String a ejecutar
        $sql="insert into categoria values (null,?,?,1);";

        //Se prepara la conexion 
        $sql=$conectar->prepare($sql);

        //Indicar en el String del SQL el parametro que utilizará
        $sql->bindValue(1,$cat_nom);
        $sql->bindValue(2,$cat_obs);
        //Ejecutar la conexion
        $sql->execute();

        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);

      }

      //Función para actualizar un registro en la tabla categoria
      public function putCategoria($cat_nom,$cat_obs,$cat_id)
      {
        //llamar la cadena de conexion de la BD
        $conectar=parent::conexion();

        //String a ejecutar
        $sql="update categoria set cat_nom=?, cat_obs=? where cat_id=?";

        //Se prepara la conexion 
        $sql=$conectar->prepare($sql);

        //Indicar en el String del SQL el parametro que utilizará
        $sql->bindValue(1,$cat_nom);
        $sql->bindValue(2,$cat_obs);
        $sql->bindValue(3,$cat_id);
        //Ejecutar la conexion
        $sql->execute();

        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);

      }

      public function deleteCategoria($cat_id)
      {
        //llamar la cadena de conexion de la BD
        $conectar=parent::conexion();

        //String a ejecutar
        $sql="delete from categoria where cat_id=?";

        //Se prepara la conexion 
        $sql=$conectar->prepare($sql);

        //Indicar en el String del SQL el parametro que utilizará
        $sql->bindValue(1,$cat_id);
        //Ejecutar la conexion
        $sql->execute();

        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);

      }
   }




?>