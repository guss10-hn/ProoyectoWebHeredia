<?php



    class Productos extends Conectar
    {
        
        public function getProductos()
        {
            $conectar=parent::conexion();

            $sql="select * from productos";

            $sql=$conectar->prepare($sql);

            $sql->execute();

            return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
        }


        public function getProductos_id($id)
        {
            $conectar=parent::conexion();

            $sql="select * from productos where id=?";

            $sql=$conectar->prepare($sql);

            $sql->bindValue(1,$id);

            $sql->execute();

            return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
        }

        public function postProductos($nombre, $pu, $cantidad, $cat_id)
        {
            //llamar la cadena de conexion de la BD
            $conectar=parent::conexion();

            //String a ejecutar
            $sql="insert into productos values (null,?,?,?,?)";

            //Se prepara la conexion 
            $sql=$conectar->prepare($sql);

            //Indicar en el String del SQL el parametro que utilizará
            $sql->bindValue(1,$nombre);
            $sql->bindValue(2,$pu);
            $sql->bindValue(3,$cantidad);
            $sql->bindValue(4,$cat_id);
            //Ejecutar la conexion
            $sql->execute();

            return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);

        }
        
        public function putProductos($nombre, $pu, $cantidad, $cat_id, $id)
      {
        //llamar la cadena de conexion de la BD
        $conectar=parent::conexion();

        //String a ejecutar
        $sql="update productos set nombre=?, pu=?, cantidad=?, cat_id=? where id=?";

        //Se prepara la conexion 
        $sql=$conectar->prepare($sql);

        //Indicar en el String del SQL el parametro que utilizará
        $sql->bindValue(1,$nombre);
        $sql->bindValue(2,$pu);
        $sql->bindValue(3,$cantidad);
        $sql->bindValue(4,$cat_id);
        $sql->bindValue(5,$id);
        //Ejecutar la conexion
        $sql->execute();

        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);

      }

      public function deleteProductos($id)
        {
            $conectar=parent::conexion();

            $sql="delete from productos where id=?";

            $sql=$conectar->prepare($sql);

            $sql->bindValue(1,$id);

            $sql->execute();

            return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

?>