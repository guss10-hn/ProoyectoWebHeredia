<?php


if ($_SERVER["REQUEST_METHOD"]=="POST")
	 {
    
    $cat_nom=$_POST['cat_nom'];
    $cat_obs=$_POST['cat_obs'];
    $cat_id=$_POST['cat_id'];
    

    $ins = json_encode(array("cat_nom"=>"$cat_nom", "cat_obs"=>"$cat_obs", "cat_id"=>"$cat_id"));

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://127.0.0.1/api_restful/controllers/categoria.php?op=update',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'PUT',
  CURLOPT_POSTFIELDS =>$ins,
  CURLOPT_HTTPHEADER => array(
    'Content-Type: text/plain'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;

}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Categoria</title>
    <link rel="stylesheet" href="../estilos.css">
</head>
<body>
    <header id="inicio">
        <div class="contenedor">
            <div class="menu">
            <p></p>
                <ul class="lista">
                    <li><a class="btn-menu" href='../clienteCategoria.php'>Regresar</a></li>
                </ul>
                </div>
        </div>
    </header>
    <center>
        <h1>Nueva Categoria</h1>
        <hr>
        <table border=1 class="table">
            <form action="" method="post">
                <tr>
                    <td><label for="cat_nom">ID Categoría: </label></td>
                    <td><input type="text" placeholder="ID de la Categoría" name="cat_id"></label></td>
                </tr>
                <tr>
                    <td><label for="cat_nom">Nombre: </label></td>
                    <td><input type="text" placeholder="Nombre de la Categoria" name="cat_nom"></label></td>
                </tr>
                <tr>
                    <td><label for="cat_obs">Observaciones: </label></td>
                    <td><input type="text" placeholder="Observaciones de la Categoria" name="cat_obs"></label></td>
                </tr>
                <tr>
                    
                    <td><input type="submit" name="Enviar" class="enlace_menu"></td>
                    <td><input type="reset" name="Borrar" class="enlace_menu"></td>
                </tr>
                

</table>
    <hr>
</body>
</html>