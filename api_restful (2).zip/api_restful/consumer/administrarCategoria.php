<?php

// Crear la vista para mostrar un pantalla todos los registros de la tabla categoria

// Consumir el Api_Restful

$endpoint="http://127.0.0.1/Parcial2/api_restful/controllers/categoria.php?op=selectall";

// convertir el json a un objeto de tipo arrive asosiativo
$datos=json_decode(file_get_contents($endpoint),true);

echo"<br>";
echo"<center>";
echo"<h1>Registros de Categorias</>";
echo"<hr>";

echo"<table border=1";
echo"<tr>";
echo"<th>No.</th>";
echo"<th>Nombre</th>";
echo"<th>Observaciones</th>";
echo"<th>Status</th>";
echo"<th>Acciones</th>";
echo"</tr>";


for($i=0;$i<count($datos);$i++)
{
echo"</tr>";
echo"<td>".$datos[$i]["cat_id"]."</td>";
echo"<td>".$datos[$i]["cat_nom"]."</td>";
echo"<td>".$datos[$i]["cat_obs"]."</td>";
echo"<td>".$datos[$i]["est"]."</td>";
echo"<td><a href=eliminar.php?cat_id?php echo $row '>Eliminar</a><a href=actualizar.php?cat_id?php echo $row '>Editar</a></td>

 <a href='Actualizar.php'>Actualizar</a></td>";
echo"</tr>";
}



echo"</table>";
echo"<hr>";
echo"</center>";

?>