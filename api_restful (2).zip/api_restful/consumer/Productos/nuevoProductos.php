<?php

if ($_SERVER["REQUEST_METHOD"]=="POST")
	 {
    
    $nombre=$_POST['nombre'];
    $pu=$_POST['pu'];
    $cantidad=$_POST['cantidad'];
    $cat_id=$_POST['cat_id'];
    

    $ins = json_encode(array("nombre"=>"$nombre", "pu"=>"$pu" ,  "cantidad"=>"$cantidad" , "cat_id"=>"$cat_id"));
     
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => 'http://127.0.0.1/api_restful/controllers/productos.php?op=insert',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => $ins,
      CURLOPT_HTTPHEADER => array(
        'Content-Type: text/plain'
      ),
    ));
    
    $response = curl_exec($curl);
    
    curl_close($curl);
    echo $response;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Productp</title>
    <link rel="stylesheet" href="../estilos.css">
</head>
<body>
    <header id="inicio">
        <div class="contenedor">
            <div class="menu">
            <p></p>
                <ul class="lista">
                    <li><a class="btn-menu" href='../clienteProductos.php'>Regresar</a></li>
                </ul>
                </div>
        </div>
    </header>
    <center>
        <h1>Nuevo Producto</h1>
        <hr>
        
        <table border=1>
            <form action="" method="post">
                <tr>
                    <td><label for="cat_nom">Nombre: </label></td>
                    <td><input type="text" placeholder="Nombre del Producto" name="nombre"></label></td>
                </tr>
                <tr>
                    <td><label for="cat_obs">Precio Unitario: </label></td>
                    <td><input type="text" placeholder="Precio Unitario del Producto" name="pu"></label></td>
                </tr>
                <tr>
                    <td><label for="cat_obs">Cantidad: </label></td>
                    <td><input type="text" placeholder="Cantidad del Producto" name="cantidad"></label></td>
                </tr>
                <tr>
                    <td><label for="cat_obs">ID de Categoría: </label></td>
                    <td><input type="text" placeholder="Categoría del Producto" name="cat_id"></label></td>
                </tr>
                <tr>
                    
                    <td><input type="submit" name="Enviar"></td>
                    <td><input type="reset" name="Borrar"></td>
                </tr>
                

</table>
    <hr>
</body>
</html>
