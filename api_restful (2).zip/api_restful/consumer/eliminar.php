<?php
  include '../config/conexion.php';
  $id = $_GET['cat_id'];
  $eliminar = "DELETE FROM categoria WHERE cat_id = '$id'";
  $elimina = $conecta->query($eliminar);
  header("location:administrarCategoria.php");
  $conecta->close();
   
?>
